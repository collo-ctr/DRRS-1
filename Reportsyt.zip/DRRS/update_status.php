<?php
session_start();
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $report_id = $_POST['report_id'];
    
    // Logic: If they clicked the green button, it's Resolved. 
    // If they just changed the dropdown, use the dropdown value.
    if (isset($_POST['submit_status'])) {
        $status = 'Resolved';
    } else {
        $status = $_POST['new_status'];
    }

    $stmt = $conn->prepare("UPDATE emergency_reports SET status = ? WHERE id = ?");
    $stmt->bind_param("si", $status, $report_id);
    
    if ($stmt->execute()) {
        header("Location: dashboard.php");
        exit();
    }
}
?>