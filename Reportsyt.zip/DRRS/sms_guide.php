<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Inter:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <title>SMS Reporting Guide | RESQ KENYA</title>
</head>
<body class="sms-page-body">

    <nav class="glass-nav">
        <div class="logo"><span>●</span> RESQ KENYA</div>
        <a href="index.php" class="back-link">← Back</a>
    </nav>

    <div class="main-wrapper">
        <section class="sms-hero">
            <p class="red-tag">NO INTERNET REQUIRED</p>
            <h1 class="giant-heading">SMS<br>REPORTING<br>GUIDE</h1>
            <p class="hero-sub">Own a basic phone with no internet? You can still report emergencies. Send an SMS using the format below and help will be dispatched.</p>
        </header>

        <div class="red-banner-box">
            <small>SEND SMS TO</small>
            <div class="big-number">22395</div>
            <p>Available 24/7 • All networks • Kenya</p>
        </div>

        <div class="dark-card-section">
            <p class="section-label">MESSAGE FORMAT</p>
            <div class="pill-container">
                <span class="pill resq">RESQ</span>
                <span class="pill type">[TYPE]</span>
                <span class="pill sev">[SEVERITY]</span>
                <span class="pill loc">[LOCATION]</span>
            </div>

            <div class="grid-2x2">
                <div class="guide-item">
                    <label>KEYWORD</label>
                    <p>Always start with <strong>RESQ</strong></p>
                </div>
                <div class="guide-item">
                    <label>TYPE</label>
                    <p>MEDICAL · FIRE · POLICE · FLOOD · ACCIDENT · GAS · MISSING · COLLAPSE</p>
                </div>
                <div class="guide-item">
                    <label>SEVERITY</label>
                    <p>LOW · MEDIUM · HIGH</p>
                </div>
                <div class="guide-item">
                    <label>LOCATION</label>
                    <p>Nearest landmark, estate or town</p>
                </div>
            </div>
        </div>

        <section class="examples-section">
            <h2 class="section-title">EXAMPLES</h2>
            <div class="example-entry">
                <small>MEDICAL — CRITICAL INJURY</small>
                <div class="code-snippet">RESQ MEDICAL HIGH Kibera Market</div>
                <p>Reports a life-threatening medical emergency near Kibera Market. Highest priority dispatched.</p>
            </div>
            <div class="example-entry">
                <small>FIRE — BUILDING FIRE</small>
                <div class="code-snippet">RESQ FIRE HIGH Westlands Arcade</div>
                <p>Reports a high-severity fire at Westlands Arcade.</p>
            </div>
        </section>

        <div class="advice-layout">
            <div class="advice-card">
                <span class="icon">📄</span>
                <h3>Keep it simple</h3>
                <p>Only the 4 fields are needed. No punctuation required. Spell out keywords clearly.</p>
            </div>
            <div class="advice-card">
                <span class="icon">🎯</span>
                <h3>Be specific</h3>
                <p>Use nearby landmarks, estate names, or road junctions for fastest response.</p>
            </div>
            <div class="advice-card">
                <span class="icon">⭐</span>
                <h3>Use correct severity</h3>
                <p>HIGH = life at risk. MEDIUM = urgent. LOW = needs attention but stable.</p>
            </div>
            <div class="advice-card">
                <span class="icon">📱</span>
                <h3>Any network</h3>
                <p>Works on Safaricom, Airtel, Telkom. No data needed — just SMS.</p>
            </div>
        </div>

        <div class="bottom-cta">
            <p>Have internet access? Use the web form for faster reporting.</p>
            <a href="report.php" class="btn-full-red">Report via Web Form</a>
        </div>
    </div>
</body>
</html>
