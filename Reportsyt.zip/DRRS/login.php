<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="style.css">
    <title>Dispatcher Login | RESQ</title>
</head>
<body>
    <div class="login-container" style="display: flex; height: 100vh; justify-content: center; align-items: center;">
        <div class="login-box" style="background: var(--card-gray); padding: 40px; border-radius: 15px; width: 350px; text-align: center;">
            <h1 style="font-size: 2.5rem; letter-spacing: 2px;">RESQ<span style="color: var(--resq-red);">.</span></h1>
            <p style="color: var(--text-muted); font-size: 12px; margin-bottom: 30px;">DISPATCHER LOGIN</p>
            
            <form action="auth.php" method="POST">
                <div style="text-align: left; margin-bottom: 20px;">
                    <label style="font-size: 10px; color: var(--text-muted);">USERNAME</label>
                    <input type="text" name="user" value="dispatcher" style="background: #111; border: 1px solid #333; color: white; width: 100%; padding: 12px; border-radius: 5px; margin-top: 5px;">
                </div>
                <div style="text-align: left; margin-bottom: 30px;">
                    <label style="font-size: 10px; color: var(--text-muted);">PASSWORD</label>
                    <input type="password" name="pass" value="resq2024" style="background: #111; border: 1px solid #333; color: white; width: 100%; padding: 12px; border-radius: 5px; margin-top: 5px;">
                </div>
                <button type="submit" class="btn-primary" style="width: 100%;">Access Dashboard</button>
            </form>
            <p style="color: #444; font-size: 11px; margin-top: 20px;">Demo: dispatcher / resq2024</p>
        </div>
    </div>
</body>
</html>