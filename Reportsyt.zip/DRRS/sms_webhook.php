<?php
include 'db.php';

// These variables are usually sent by the SMS API (like Africa's Talking)
$from = $_POST['from']; // Phone number
$text = $_POST['text']; // e.g., "RESQ MEDICAL HIGH KIBERA"

// Split the message by spaces
$parts = explode(" ", $text);

if (strtoupper($parts[0]) == "RESQ") {
    $type     = $parts[1] ?? 'Unknown';
    $severity = $parts[2] ?? 'Medium';
    $location = $parts[3] ?? 'Unknown Location';
    $ref_num  = "SMS-" . rand(100000, 999999);
    
    // Auto-calculate score for SMS
    $score = ($severity == 'HIGH') ? 90 : 50;

    $sql = "INSERT INTO emergency_reports (ref_num, type, severity, location, description, priority_score) 
            VALUES ('$ref_num', '$type', '$severity', '$location', 'Reported via SMS from $from', '$score')";
    
    $conn->query($sql);
}
?>